"""Window-scoped keyboard controls."""
