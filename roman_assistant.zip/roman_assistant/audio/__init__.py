"""Audio capture and transcription."""
