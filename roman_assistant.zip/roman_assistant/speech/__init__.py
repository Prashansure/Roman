"""Speech synthesis lifecycle."""
