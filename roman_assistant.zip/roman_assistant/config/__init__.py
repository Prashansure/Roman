"""Roman application configuration."""
