"""Premium, local-first chat interface for Roman."""

from __future__ import annotations

import io
import json
import math
import re
import tokenize
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import ttk

from audio.microphone import list_input_devices
from config import settings as app_settings
from controls.keyboard import bind_controls
from core.state import AssistantState

BG = "#090a0c"
SURFACE = "#15171b"
SURFACE_HI = "#202329"
TEXT = "#eceef2"
MUTED = "#939aa5"
BLUE = "#80b9ff"
GREEN = "#75d6a1"
AMBER = "#e3bd79"
RED = "#f08a8a"
SEPARATOR = "#22252a"
FONT = "Segoe UI"
CODE_FONT = "Cascadia Code"
MAX_LANE = 820
HISTORY_LIMIT = 500


class RoundedBubble(tk.Canvas):
    """Canvas-backed rounded surface for compact user message bubbles."""

    def __init__(self, parent, fill: str) -> None:
        super().__init__(parent, bg=BG, highlightthickness=0, borderwidth=0, width=240, height=58)
        self.fill = fill
        self.panel = tk.Frame(self, bg=fill, padx=13, pady=9)
        self.window = self.create_window((7, 7), window=self.panel, anchor="nw")
        self.panel.bind("<Configure>", self._sync_size)
        self.bind("<Configure>", self._draw)

    def _sync_size(self, _event=None) -> None:
        self.update_idletasks()
        width = max(88, self.panel.winfo_reqwidth() + 14)
        height = max(48, self.panel.winfo_reqheight() + 14)
        self.configure(width=width, height=height)
        self.itemconfigure(self.window, width=width - 14, height=height - 14)
        self._draw()

    def _draw(self, _event=None) -> None:
        width, height = max(1, self.winfo_width()), max(1, self.winfo_height())
        radius = min(16, width // 2, height // 2)
        points = [radius, 0, width-radius, 0, width, radius, width, height-radius,
                  width-radius, height, radius, height, 0, height-radius, 0, radius]
        self.delete("bubble")
        self.create_polygon(points, smooth=True, splinesteps=14, fill=self.fill, outline="", tags="bubble")
        self.tag_lower("bubble")


class RomanWindow:
    def __init__(self, root: tk.Tk, assistant) -> None:
        self.root = root
        self.assistant = assistant
        self.logo_image = None
        self.small_logo_image = None
        self.state = AssistantState.ONLINE
        self.chat_items: list[dict] = []
        self.message_widgets: list[dict] = []
        self._placeholder_active = True
        self._history_open = False
        self._sidebar_visible = False
        self._status_phase = 0
        self._typing_phase = 0
        self._typing_active = False
        self._response_streaming = False
        self._active_response = None
        self._resize_job = None
        self.preferences_path = Path(app_settings.BASE_DIR) / "config" / "roman_ui_preferences.json"
        self.preferences = self._load_preferences()
        if isinstance(self.preferences.get("microphone_index"), int):
            app_settings.MIC_DEVICE_INDEX = self.preferences["microphone_index"]

        self.root.title("Roman")
        self.root.configure(bg=BG)
        self.root.minsize(*app_settings.MIN_WINDOW_SIZE)
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self._load_logo()
        self._build()

        saved = self.assistant.memory.list_conversations()
        if saved:
            messages = self.assistant.load_conversation(saved[0]["id"])
            self._show_messages(messages[-HISTORY_LIMIT:])
        else:
            self._show_welcome()
        self._set_state(AssistantState.ONLINE, "Ready")
        self.root.after(30, self._drain_events)
        self.root.after(550, self._animate_status)

    def _load_preferences(self) -> dict:
        try:
            with self.preferences_path.open("r", encoding="utf-8") as handle:
                data = json.load(handle)
            return data if isinstance(data, dict) else {}
        except (OSError, json.JSONDecodeError):
            return {}

    def _text_size(self) -> int:
        size = self.preferences.get("text_size", 11)
        return size if size in (10, 11, 13) else 11

    def _save_preferences(self) -> None:
        try:
            self.preferences_path.parent.mkdir(parents=True, exist_ok=True)
            temp = self.preferences_path.with_suffix(".tmp")
            with temp.open("w", encoding="utf-8") as handle:
                json.dump(self.preferences, handle, ensure_ascii=False, indent=2)
            temp.replace(self.preferences_path)
        except OSError as exc:
            self._append_system(f"Could not save settings: {exc}")

    def _load_logo(self) -> None:
        path = Path(app_settings.ASSETS_DIR) / "roman_logo.png"
        try:
            source = tk.PhotoImage(file=str(path))
            factor = max(1, math.ceil(max(source.width(), source.height()) / 42))
            self.logo_image = source.subsample(factor, factor) if factor > 1 else source
            small_factor = max(1, factor * 2)
            self.small_logo_image = source.subsample(small_factor, small_factor)
        except (tk.TclError, OSError):
            self.logo_image = self.small_logo_image = None

    def _build(self) -> None:
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(1, weight=1)
        self._build_sidebar()
        self._build_main()

    def _build_sidebar(self) -> None:
        self.sidebar = tk.Frame(self.root, bg="#101114", width=254)
        self.sidebar.grid_propagate(False)
        self.sidebar.grid_columnconfigure(0, weight=1)
        self.sidebar.grid_rowconfigure(3, weight=1)

        top = tk.Frame(self.sidebar, bg="#101114")
        top.grid(row=0, column=0, sticky="ew", padx=16, pady=(20, 14))
        if self.logo_image:
            tk.Label(top, image=self.logo_image, bg="#101114").pack(side="left", padx=(0, 10))
        tk.Label(top, text="Roman", bg="#101114", fg=TEXT, font=(FONT, 13, "bold")).pack(side="left")

        self._sidebar_action("＋   New conversation", self._new_conversation, row=1, accent=True)
        self._sidebar_action("◷   Conversation history", self._toggle_history, row=2)

        self.history_panel = tk.Frame(self.sidebar, bg="#101114")
        self.history_panel.grid(row=3, column=0, sticky="nsew", padx=12)
        self.history_panel.grid_rowconfigure(0, weight=1)
        self.history_panel.grid_columnconfigure(0, weight=1)
        self.history_canvas = tk.Canvas(self.history_panel, bg="#101114", highlightthickness=0, borderwidth=0)
        self.history_canvas.grid(row=0, column=0, sticky="nsew")
        history_scroll = tk.Scrollbar(
            self.history_panel, command=self.history_canvas.yview, bg="#101114",
            troughcolor="#101114", activebackground="#41464f", relief="flat", borderwidth=0, width=7,
        )
        history_scroll.grid(row=0, column=1, sticky="ns")
        self.history_canvas.configure(yscrollcommand=history_scroll.set)
        self.history_list = tk.Frame(self.history_canvas, bg="#101114")
        self.history_window = self.history_canvas.create_window((0, 0), window=self.history_list, anchor="nw")
        self.history_list.bind("<Configure>", lambda _event: self.history_canvas.configure(scrollregion=self.history_canvas.bbox("all")))
        self.history_canvas.bind("<Configure>", lambda event: self.history_canvas.itemconfigure(self.history_window, width=event.width))
        self.history_panel.grid_remove()

        tk.Frame(self.sidebar, bg=SEPARATOR, height=1).grid(row=4, column=0, sticky="ew", padx=16, pady=(10, 8))
        lower = tk.Frame(self.sidebar, bg="#101114")
        lower.grid(row=6, column=0, sticky="ew", padx=0, pady=(0, 14))
        self._sidebar_action("Settings", self._open_settings, row=0, parent=lower)
        self._sidebar_action("Voice settings", self._open_voice_settings, row=1, parent=lower)
        self._sidebar_action("Model information", self._open_model_info, row=2, parent=lower)

    def _sidebar_action(self, label: str, command, row: int, parent=None, accent=False) -> tk.Label:
        parent = parent or self.sidebar
        background = SURFACE_HI if accent else parent.cget("bg")
        foreground = BLUE if accent else TEXT
        item = tk.Label(
            parent, text=label, bg=background, fg=foreground,
            anchor="w", padx=12, pady=10, font=(FONT, 10), cursor="hand2",
        )
        item.grid(row=row, column=0, sticky="ew", padx=12 if parent is self.sidebar else 4, pady=3)
        item.bind("<Button-1>", lambda _event: command())
        item.bind("<Enter>", lambda _event: item.configure(bg=SURFACE_HI))
        item.bind("<Leave>", lambda _event: item.configure(bg=background))
        return item

    def _build_main(self) -> None:
        self.main = tk.Frame(self.root, bg=BG)
        self.main.grid(row=0, column=1, sticky="nsew")
        self.main.grid_rowconfigure(1, weight=1)
        self.main.grid_columnconfigure(0, weight=1)
        self._build_topbar()
        self._build_chat()
        self._build_composer()

    def _build_topbar(self) -> None:
        bar = tk.Frame(self.main, bg=BG, height=68)
        bar.grid(row=0, column=0, sticky="ew", padx=28, pady=(12, 0))
        bar.grid_columnconfigure(1, weight=1)
        self.sidebar_toggle = self._soft_button(bar, "☰", self._toggle_sidebar, width=3)
        self.sidebar_toggle.grid(row=0, column=0, sticky="w", padx=(0, 14))

        brand = tk.Frame(bar, bg=BG)
        brand.grid(row=0, column=1, sticky="w")
        if self.small_logo_image:
            tk.Label(brand, image=self.small_logo_image, bg=BG).pack(side="left", padx=(0, 8))
        tk.Label(brand, text="Roman", bg=BG, fg=TEXT, font=(FONT, 12, "bold")).pack(side="left")

        status_group = tk.Frame(bar, bg=BG)
        status_group.grid(row=0, column=2, sticky="e")
        self.status_dot = tk.Label(status_group, text="●", bg=BG, fg=GREEN, font=(FONT, 9))
        self.status_dot.pack(side="left", padx=(0, 6))
        self.status_text = tk.Label(status_group, text="Online", bg=BG, fg=MUTED, font=(FONT, 9))
        self.status_text.pack(side="left")

    def _build_chat(self) -> None:
        holder = tk.Frame(self.main, bg=BG)
        holder.grid(row=1, column=0, sticky="nsew", padx=12)
        holder.grid_rowconfigure(0, weight=1)
        holder.grid_columnconfigure(0, weight=1)
        self.chat_canvas = tk.Canvas(holder, bg=BG, highlightthickness=0, borderwidth=0)
        self.chat_canvas.grid(row=0, column=0, sticky="nsew")
        self.message_column = tk.Frame(self.chat_canvas, bg=BG)
        self.message_window = self.chat_canvas.create_window((0, 0), window=self.message_column, anchor="nw")
        self.message_column.bind("<Configure>", self._on_messages_changed)
        self.chat_canvas.bind("<Configure>", self._on_chat_resize)
        self.scrollbar = tk.Scrollbar(
            holder, command=self.chat_canvas.yview, bg=BG, troughcolor=BG,
            activebackground="#41464f", relief="flat", borderwidth=0, width=8,
        )
        self.scrollbar.grid(row=0, column=1, sticky="ns")
        self.chat_canvas.configure(yscrollcommand=self.scrollbar.set)
        self.chat_canvas.bind_all("<MouseWheel>", self._on_mousewheel)

    def _build_composer(self) -> None:
        area = tk.Frame(self.main, bg=BG)
        area.grid(row=2, column=0, sticky="ew", padx=20, pady=(6, 20))
        area.grid_columnconfigure(0, weight=1)

        self.composer_canvas = tk.Canvas(area, bg=BG, height=142, highlightthickness=0, borderwidth=0)
        self.composer_canvas.grid(row=0, column=0, sticky="ew")
        self.composer_canvas.bind("<Configure>", self._draw_composer)
        self.composer = tk.Frame(self.composer_canvas, bg=SURFACE)
        self.composer_window = self.composer_canvas.create_window((1, 1), window=self.composer, anchor="nw")
        self.composer.grid_columnconfigure(0, weight=1)

        self.entry = tk.Text(
            self.composer, height=2, wrap=tk.WORD, bg=SURFACE, fg=MUTED,
            insertbackground=TEXT, relief="flat", borderwidth=0, padx=12, pady=12,
            font=(FONT, 11), undo=True, highlightthickness=0,
        )
        self.entry.insert("1.0", "Message Roman…")
        self.entry.bind("<FocusIn>", self._clear_placeholder)
        self.entry.bind("<FocusOut>", self._restore_placeholder)
        self.entry.bind("<Return>", self._send_from_return)
        self.entry.bind("<Shift-Return>", self._insert_newline)
        self.entry.grid(row=0, column=0, columnspan=3, sticky="ew", padx=7, pady=(7, 0))

        controls = tk.Frame(self.composer, bg=SURFACE)
        controls.grid(row=1, column=0, columnspan=3, sticky="ew", padx=12, pady=(0, 8))
        controls.grid_columnconfigure(0, weight=1)
        self.voice_button = self._soft_button(controls, "◉  Voice", self.assistant.toggle_listening)
        self.voice_button.grid(row=0, column=1, padx=(0, 8))
        self.stop_button = self._soft_button(controls, "■  Stop", self.assistant.cancel, foreground=RED)
        self.stop_button.grid(row=0, column=2)
        self.stop_button.grid_remove()

        tk.Label(
            area, text="ENTER TO SEND  ·  SHIFT + ENTER FOR A NEW LINE  ·  C TO TALK",
            bg=BG, fg="#6f7782", font=(FONT, 8),
        ).grid(row=1, column=0, sticky="e", padx=5, pady=(7, 0))
        bind_controls(
            self.root,
            {"c": self.assistant.toggle_listening, "a": self.assistant.resume,
             "b": self.assistant.pause, "e": self.assistant.cancel, "d": self.close,
             "escape": self.assistant.cancel},
            self.entry,
        )

    @staticmethod
    def _rounded_points(width: int, height: int, radius: int) -> list[int]:
        radius = max(5, min(radius, width // 2, height // 2))
        return [
            radius, 0, width - radius, 0, width, radius, width, height - radius,
            width - radius, height, radius, height, 0, height - radius, 0, radius,
        ]

    def _draw_composer(self, event=None) -> None:
        width = max(1, self.composer_canvas.winfo_width())
        height = 128
        self.composer_canvas.configure(height=height)
        self.composer_canvas.delete("surface")
        self.composer_canvas.create_polygon(
            self._rounded_points(width, height, 18), smooth=True, splinesteps=18,
            fill=SURFACE, outline="#25282e", width=1, tags="surface",
        )
        self.composer_canvas.tag_lower("surface")
        self.composer_canvas.coords(self.composer_window, 8, 8)
        self.composer_canvas.itemconfigure(self.composer_window, width=max(1, width - 16), height=height - 16)

    def _soft_button(self, parent, label: str, command, width=None, foreground=TEXT) -> tk.Label:
        widget = tk.Label(
            parent, text=label, bg=SURFACE, fg=foreground, padx=12, pady=8,
            font=(FONT, 9), cursor="hand2", width=width,
        )
        widget.bind("<Button-1>", lambda _event: command())
        widget.bind("<Enter>", lambda _event: widget.configure(bg=SURFACE_HI))
        widget.bind("<Leave>", lambda _event: widget.configure(bg=SURFACE))
        return widget

    def _clear_placeholder(self, _event=None) -> None:
        if self._placeholder_active:
            self.entry.delete("1.0", tk.END)
            self.entry.configure(fg=TEXT)
            self._placeholder_active = False

    def _restore_placeholder(self, _event=None) -> None:
        if not self.entry.get("1.0", "end-1c").strip():
            self.entry.delete("1.0", tk.END)
            self.entry.insert("1.0", "Message Roman…")
            self.entry.configure(fg=MUTED)
            self._placeholder_active = True

    def _send_from_return(self, _event=None):
        self._send()
        return "break"

    def _insert_newline(self, _event=None):
        self.entry.insert(tk.INSERT, "\n")
        return "break"

    def _send(self) -> None:
        if self._placeholder_active:
            return
        message = self.entry.get("1.0", "end-1c").strip()
        if not message:
            return
        self.entry.delete("1.0", tk.END)
        self.assistant.send_message(message)

    def _show_welcome(self) -> None:
        self._clear_chat_widgets()
        welcome = tk.Frame(self.message_column, bg=BG)
        welcome.pack(fill="x", pady=(125, 30))
        if self.logo_image:
            tk.Label(welcome, image=self.logo_image, bg=BG).pack(pady=(0, 16))
        tk.Label(welcome, text="What can I help with?", bg=BG, fg=TEXT, font=(FONT, 24, "bold")).pack()
        tk.Label(
            welcome, text="A private local assistant, ready when you are.",
            bg=BG, fg=MUTED, font=(FONT, 11),
        ).pack(pady=(9, 0))
        self.chat_canvas.yview_moveto(0)

    def _show_messages(self, messages) -> None:
        self._clear_chat_widgets()
        self.chat_items = []
        for message in messages:
            self.chat_items.append({"role": message["role"], "text": message["content"], "streaming": False})
            self._render_item(self.chat_items[-1])
        if not self.chat_items:
            self._show_welcome()
        self._scroll_bottom()

    def _clear_chat_widgets(self) -> None:
        for child in self.message_column.winfo_children():
            child.destroy()
        self.message_widgets.clear()

    def _new_conversation(self) -> None:
        self.assistant.new_conversation()
        self.chat_items = []
        self._response_streaming = False
        self._active_response = None
        self._stop_typing_indicator()
        self._show_welcome()
        self._refresh_history()

    def _toggle_sidebar(self) -> None:
        if self._sidebar_visible:
            self.sidebar.grid_remove()
            self._sidebar_visible = False
        else:
            self.sidebar.grid(row=0, column=0, sticky="nsw")
            self.main.grid_configure(row=0, column=1, sticky="nsew")
            self._sidebar_visible = True

    def _toggle_history(self) -> None:
        self._history_open = not self._history_open
        if self._history_open:
            self.history_panel.grid()
            self._refresh_history()
        else:
            self.history_panel.grid_remove()

    def _refresh_history(self) -> None:
        for child in self.history_list.winfo_children():
            child.destroy()
        sessions = self.assistant.memory.list_conversations()
        if not sessions:
            tk.Label(self.history_list, text="No saved conversations yet", bg="#101114", fg=MUTED,
                     font=(FONT, 9), wraplength=210, justify="left").pack(anchor="w", padx=8, pady=8)
            return
        for session in sessions[:80]:
            messages = session["messages"]
            first_user = next((row["content"] for row in messages if row["role"] == "user"), "Conversation")
            try:
                stamp = datetime.fromisoformat(session["started_at"]).strftime("%b %d · %H:%M")
            except (ValueError, TypeError):
                stamp = session["started_at"][:10]
            title = first_user.replace("\n", " ").strip()[:35] or "Conversation"
            entry = tk.Label(
                self.history_list, text=f"{title}\n{stamp}", bg="#101114", fg=MUTED,
                anchor="w", justify="left", font=(FONT, 9), padx=8, pady=8,
                wraplength=215, cursor="hand2",
            )
            entry.pack(fill="x", pady=1)
            entry.bind("<Enter>", lambda _event, label=entry: label.configure(bg=SURFACE_HI, fg=TEXT))
            entry.bind("<Leave>", lambda _event, label=entry: label.configure(bg="#101114", fg=MUTED))
            entry.bind("<Button-1>", lambda _event, sid=session["id"]: self._open_conversation(sid))

    def _open_conversation(self, session_id: str) -> None:
        messages = self.assistant.load_conversation(session_id)
        self.chat_items = []
        self._response_streaming = False
        self._active_response = None
        self._stop_typing_indicator()
        self._show_messages(messages[-HISTORY_LIMIT:])

    def _open_settings(self) -> None:
        window = self._dialog("Settings", 420, 330)
        tk.Label(window, text="Appearance", bg=BG, fg=TEXT, font=(FONT, 14, "bold")).pack(anchor="w", padx=22, pady=(22, 12))
        tk.Label(window, text="Response text size", bg=BG, fg=MUTED, font=(FONT, 10)).pack(anchor="w", padx=22)
        controls = tk.Frame(window, bg=BG)
        controls.pack(anchor="w", padx=18, pady=(8, 20))
        current = self._text_size()
        for label, size in (("Small", 10), ("Standard", 11), ("Large", 13)):
            item = tk.Label(
                controls, text=label, bg=SURFACE_HI if current == size else BG,
                fg=TEXT, padx=12, pady=8, font=(FONT, 9), cursor="hand2",
            )
            item.pack(side="left", padx=4)
            item.bind("<Button-1>", lambda _event, value=size, dialog=window: self._set_text_size(value, dialog))
        reduce_var = tk.BooleanVar(value=bool(self.preferences.get("reduce_motion", False)))
        toggle = tk.Checkbutton(
            window, text="Reduce motion", variable=reduce_var, command=lambda: self._set_reduce_motion(reduce_var.get()),
            bg=BG, fg=TEXT, activebackground=BG, activeforeground=TEXT, selectcolor=SURFACE,
            font=(FONT, 10), relief="flat", highlightthickness=0,
        )
        toggle.pack(anchor="w", padx=22)
        tk.Label(window, text="Changes apply to the chat immediately.", bg=BG, fg=MUTED, font=(FONT, 9)).pack(anchor="w", padx=22, pady=(16, 0))

    def _set_text_size(self, size: int, dialog) -> None:
        self.preferences["text_size"] = size
        self._save_preferences()
        self._rerender_messages()
        dialog.destroy()

    def _set_reduce_motion(self, value: bool) -> None:
        self.preferences["reduce_motion"] = value
        self._save_preferences()

    def _open_voice_settings(self) -> None:
        window = self._dialog("Voice settings", 480, 300)
        tk.Label(window, text="Microphone input", bg=BG, fg=TEXT, font=(FONT, 14, "bold")).pack(anchor="w", padx=22, pady=(22, 8))
        try:
            devices = list_input_devices()
        except Exception as exc:
            devices = []
            tk.Label(window, text=f"Audio devices are unavailable: {exc}", bg=BG, fg=RED,
                     wraplength=430, justify="left", font=(FONT, 9)).pack(anchor="w", padx=22, pady=(0, 10))
        if not devices:
            tk.Label(window, text="No microphone inputs were detected.", bg=BG, fg=MUTED, font=(FONT, 10)).pack(anchor="w", padx=22, pady=(8, 0))
            return
        labels = [f"{name}  ·  device {index}" for index, name in devices]
        lookup = {label: index for (index, _name), label in zip(devices, labels)}
        selected = tk.StringVar()
        current_label = next((label for label in labels if lookup[label] == app_settings.MIC_DEVICE_INDEX), "")
        selected.set(current_label)
        style = ttk.Style(window)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure(
            "Roman.TCombobox", fieldbackground=SURFACE, background=SURFACE_HI,
            foreground=TEXT, arrowcolor=TEXT, bordercolor=SEPARATOR,
        )
        style.map("Roman.TCombobox", fieldbackground=[("readonly", SURFACE)], foreground=[("readonly", TEXT)])
        combo = ttk.Combobox(window, style="Roman.TCombobox", state="readonly", values=labels, textvariable=selected, width=48)
        combo.pack(anchor="w", padx=22, pady=(4, 8))
        note_text = "The selected input is used for the next voice recording." if current_label else "Choose an input to replace the unavailable configured device."
        note = tk.Label(window, text=note_text, bg=BG, fg=MUTED, font=(FONT, 9))
        note.pack(anchor="w", padx=22, pady=(8, 0))

        def apply_device(_event=None):
            index = lookup.get(selected.get())
            if index is not None:
                app_settings.MIC_DEVICE_INDEX = index
                self.preferences["microphone_index"] = index
                self._save_preferences()
                note.configure(text="Microphone updated.", fg=GREEN)

        combo.bind("<<ComboboxSelected>>", apply_device)

    def _open_model_info(self) -> None:
        window = self._dialog("Model information", 430, 310)
        tk.Label(window, text="Running locally", bg=BG, fg=TEXT, font=(FONT, 14, "bold")).pack(anchor="w", padx=22, pady=(22, 14))
        details = (
            ("Chat model", app_settings.OLLAMA_MODEL),
            ("Chat runtime", "Ollama · local"),
            ("Speech recognition", f"Faster-Whisper · {app_settings.WHISPER_MODEL}"),
            ("Compute", f"{app_settings.WHISPER_DEVICE.upper()} · {app_settings.WHISPER_COMPUTE_TYPE}"),
            ("Speech output", "Windows SAPI"),
        )
        for name, value in details:
            row = tk.Frame(window, bg=BG)
            row.pack(fill="x", padx=22, pady=5)
            tk.Label(row, text=name, bg=BG, fg=MUTED, font=(FONT, 9), width=20, anchor="w").pack(side="left")
            tk.Label(row, text=value, bg=BG, fg=TEXT, font=(FONT, 9), anchor="w").pack(side="left")

    def _dialog(self, title: str, width: int, height: int) -> tk.Toplevel:
        window = tk.Toplevel(self.root)
        window.title(title)
        window.configure(bg=BG)
        window.geometry(f"{width}x{height}")
        window.resizable(False, False)
        window.transient(self.root)
        window.grab_set()
        return window

    def _rerender_messages(self) -> None:
        self._clear_chat_widgets()
        for item in self.chat_items:
            self._render_item(item)
        self._scroll_bottom()

    def _body_chars(self) -> int:
        width = max(360, self.chat_canvas.winfo_width())
        lane = min(MAX_LANE, width - 72)
        return max(34, min(100, lane // 9))

    def _render_item(self, item: dict) -> None:
        role = item["role"]
        lane_width = min(MAX_LANE, max(320, self.chat_canvas.winfo_width() - 72))
        row = tk.Frame(self.message_column, bg=BG)
        row.pack(fill="x", padx=12, pady=(9, 13))
        row.grid_columnconfigure(0, weight=1)
        row.grid_columnconfigure(2, weight=1)
        content = tk.Frame(row, bg=BG, width=lane_width)
        content.grid(row=0, column=1, sticky="ew")
        content.grid_propagate(False)
        chars = self._body_chars()
        text_size = self._text_size()

        if role == "user":
            bubble = RoundedBubble(content, SURFACE_HI)
            bubble.pack(anchor="e")
            text = tk.Text(
                bubble.panel, wrap=tk.WORD, width=min(chars, max(22, min(chars, max((len(line) for line in item["text"].splitlines()), default=22)))),
                height=1, bg=SURFACE_HI, fg=TEXT, font=(FONT, text_size),
                relief="flat", borderwidth=0, padx=0, pady=0, highlightthickness=0,
                spacing1=2, spacing3=3, state="normal",
            )
            text.pack()
            self._set_plain_text(text, item["text"], editable=True)
            text.configure(state="disabled")
        elif role == "system":
            color = RED if item.get("error") else MUTED
            text = tk.Label(
                content, text=item["text"], bg=BG, fg=color,
                font=(FONT, 9), wraplength=lane_width, justify="left",
            )
            text.pack(anchor="w", pady=(2, 5))
        else:
            header = tk.Frame(content, bg=BG)
            header.pack(anchor="w", fill="x", pady=(0, 6))
            if self.small_logo_image:
                tk.Label(header, image=self.small_logo_image, bg=BG).pack(side="left", padx=(0, 7))
            tk.Label(header, text="Roman", bg=BG, fg=TEXT, font=(FONT, 10, "bold")).pack(side="left")
            text = tk.Text(
                content, wrap=tk.WORD, width=chars, height=1, bg=BG, fg=TEXT,
                font=(FONT, text_size), relief="flat", borderwidth=0, padx=0, pady=2,
                highlightthickness=0, spacing1=2, spacing3=7, state="normal",
            )
            text.pack(anchor="w", fill="x")
            self._configure_markdown_tags(text, text_size)
            if item.get("streaming"):
                if item["text"]:
                    text.insert(tk.END, item["text"])
                else:
                    dots = tk.Label(content, text="●  ●  ●", bg=BG, fg=MUTED, font=(FONT, 9))
                    dots.pack(anchor="w", pady=(3, 8))
                    item["typing_widget"] = dots
                text.configure(state="disabled")
            else:
                self._render_markdown(text, item["text"])
            item["text_widget"] = text
            item["content_frame"] = content
            item["header_frame"] = header

        item["row_widget"] = row
        item["main_frame"] = content
        item["text_widget"] = text
        self.message_widgets.append(item)
        self._update_message_height(item)
        if role == "system":
            self.root.update_idletasks()
            content.configure(height=text.winfo_reqheight() + 8)

    def _update_message_height(self, item: dict) -> None:
        widget = item.get("text_widget")
        if widget is None or not widget.winfo_exists():
            return
        if not isinstance(widget, tk.Text):
            self.root.update_idletasks()
            item["main_frame"].configure(height=widget.winfo_reqheight() + 8)
            return
        try:
            count = widget.count("1.0", "end-1c", "displaylines")
            lines = count[0] if count else 1
            widget.configure(height=max(1, lines))
            widget.update_idletasks()
            item["main_frame"].configure(height=max(widget.winfo_reqheight() + 32, 56))
        except tk.TclError:
            return

    def _configure_markdown_tags(self, widget: tk.Text, size: int) -> None:
        widget.tag_configure("paragraph", spacing1=1, spacing3=size)
        widget.tag_configure("heading1", font=(FONT, size + 8, "bold"), spacing1=15, spacing3=12)
        widget.tag_configure("heading2", font=(FONT, size + 5, "bold"), spacing1=13, spacing3=10)
        widget.tag_configure("heading3", font=(FONT, size + 2, "bold"), spacing1=11, spacing3=8)
        widget.tag_configure("bold", font=(FONT, size, "bold"))
        widget.tag_configure("italic", font=(FONT, size, "italic"))
        widget.tag_configure("inline_code", font=(CODE_FONT, size - 1), foreground="#c5d9f2", background=SURFACE)
        widget.tag_configure("list", lmargin1=20, lmargin2=35, spacing3=5)
        widget.tag_configure("quote", lmargin1=14, lmargin2=20, foreground=MUTED, spacing1=4, spacing3=6)
        widget.tag_configure("link", foreground=BLUE, underline=True)

    def _render_markdown(self, widget: tk.Text, markdown: str) -> None:
        widget.configure(state="normal")
        widget.delete("1.0", tk.END)
        lines = markdown.splitlines()
        index = 0
        while index < len(lines):
            line = lines[index]
            if line.strip().startswith("```"):
                language = line.strip()[3:].strip() or "code"
                index += 1
                code_lines = []
                while index < len(lines) and not lines[index].strip().startswith("```"):
                    code_lines.append(lines[index])
                    index += 1
                self._insert_code_block(widget, "\n".join(code_lines), language)
                index += 1
                continue
            if not line.strip():
                index += 1
                continue
            heading = re.match(r"^(#{1,3})\s+(.*)$", line)
            if heading:
                level = len(heading.group(1))
                self._insert_inline(widget, heading.group(2), f"heading{level}")
                widget.insert(tk.END, "\n")
                index += 1
                continue
            if line.lstrip().startswith(">"):
                self._insert_inline(widget, line.lstrip()[1:].lstrip(), "quote")
                widget.insert(tk.END, "\n", "quote")
                index += 1
                continue
            list_match = re.match(r"^\s*(?:[-*+]\s+|(\d+)\.\s+)(.*)$", line)
            if list_match:
                while index < len(lines):
                    item = re.match(r"^\s*(?:[-*+]\s+|(\d+)\.\s+)(.*)$", lines[index])
                    if not item:
                        break
                    bullet = f"{item.group(1)}." if item.group(1) else "•"
                    widget.insert(tk.END, f"{bullet}  ", "list")
                    self._insert_inline(widget, item.group(2), "list")
                    widget.insert(tk.END, "\n", "list")
                    index += 1
                widget.insert(tk.END, "\n")
                continue
            paragraph = [line]
            index += 1
            while index < len(lines) and lines[index].strip() and not lines[index].strip().startswith("```") and not re.match(r"^(#{1,3})\s+", lines[index]) and not re.match(r"^\s*(?:[-*+]\s+|\d+\.\s+)", lines[index]):
                paragraph.append(lines[index])
                index += 1
            self._insert_inline(widget, "\n".join(paragraph), "paragraph")
            widget.insert(tk.END, "\n", "paragraph")
        if not markdown:
            widget.insert(tk.END, "")
        widget.configure(state="disabled")
        self._update_message_height_for_widget(widget)

    def _insert_inline(self, widget: tk.Text, text: str, base_tag: str) -> None:
        pattern = re.compile(r"(\*\*.+?\*\*|__.+?__|`[^`]+`|\*[^*]+\*|_[^_]+_|\[[^\]]+\]\([^)]+\))")
        offset = 0
        for match in pattern.finditer(text):
            if match.start() > offset:
                widget.insert(tk.END, text[offset:match.start()], base_tag)
            token = match.group(0)
            if token.startswith(("**", "__")):
                widget.insert(tk.END, token[2:-2], (base_tag, "bold"))
            elif token.startswith("`"):
                widget.insert(tk.END, token[1:-1], (base_tag, "inline_code"))
            elif token.startswith(("*", "_")):
                widget.insert(tk.END, token[1:-1], (base_tag, "italic"))
            else:
                link = re.match(r"\[([^\]]+)\]\(([^)]+)\)", token)
                if link:
                    widget.insert(tk.END, link.group(1), (base_tag, "link"))
            offset = match.end()
        if offset < len(text):
            widget.insert(tk.END, text[offset:], base_tag)

    def _insert_code_block(self, widget: tk.Text, code: str, language: str) -> None:
        panel = tk.Frame(widget, bg=SURFACE, padx=10, pady=8, highlightthickness=0)
        toolbar = tk.Frame(panel, bg=SURFACE)
        toolbar.pack(fill="x", pady=(0, 6))
        tk.Label(toolbar, text=language.upper(), bg=SURFACE, fg=MUTED, font=(FONT, 8, "bold")).pack(side="left")
        copy = tk.Label(toolbar, text="Copy", bg=SURFACE, fg=BLUE, font=(FONT, 8), cursor="hand2", padx=7)
        copy.pack(side="right")
        copy.bind("<Button-1>", lambda _event, value=code: self._copy_code(value, copy))

        code_area = tk.Frame(panel, bg=SURFACE)
        code_area.pack(fill="x")
        lines = max(1, len(code.splitlines()))
        code_text = tk.Text(
            code_area, wrap="none", height=min(22, lines), width=max(32, min(self._body_chars(), max((len(line) for line in code.splitlines()), default=32))),
            bg=SURFACE, fg=TEXT, insertbackground=TEXT, font=(CODE_FONT, 9),
            relief="flat", borderwidth=0, padx=2, pady=3, highlightthickness=0,
        )
        code_text.pack(side="top", fill="x")
        code_text.insert("1.0", code)
        code_text.tag_configure("kw", foreground="#8cbcff")
        code_text.tag_configure("str", foreground="#9bd49a")
        code_text.tag_configure("comment", foreground="#7f8995", font=(CODE_FONT, 9, "italic"))
        code_text.tag_configure("num", foreground="#d6aaff")
        code_text.tag_configure("builtin", foreground="#f2c879")
        code_text.tag_configure("function", foreground="#7fd4da")
        self._highlight_code(code_text, code, language)
        code_text.configure(state="disabled")
        if code and max((len(row) for row in code.splitlines()), default=0) > self._body_chars():
            bar = tk.Scrollbar(code_area, orient="horizontal", command=code_text.xview, bg=SURFACE, troughcolor=SURFACE)
            bar.pack(fill="x")
            code_text.configure(xscrollcommand=bar.set)
        widget.window_create(tk.END, window=panel, align="top")
        widget.insert(tk.END, "\n\n")

    @staticmethod
    def _highlight_code(widget: tk.Text, code: str, language: str) -> None:
        if language.casefold() in {"py", "python", "python3"}:
            try:
                for token in tokenize.generate_tokens(io.StringIO(code).readline):
                    if token.type == tokenize.NAME and token.string in __import__("keyword").kwlist:
                        tag = "kw"
                    elif token.type == tokenize.STRING:
                        tag = "str"
                    elif token.type == tokenize.COMMENT:
                        tag = "comment"
                    elif token.type == tokenize.NUMBER:
                        tag = "num"
                    elif token.type == tokenize.NAME and token.string in {"True", "False", "None", "print", "len", "range", "self"}:
                        tag = "builtin"
                    else:
                        continue
                    widget.tag_add(tag, f"{token.start[0]}.{token.start[1]}", f"{token.end[0]}.{token.end[1]}")
                return
            except (tokenize.TokenError, IndentationError, SyntaxError):
                pass
        keywords = r"\b(?:const|let|var|function|return|if|else|for|while|class|import|from|async|await|def|new|true|false|null|None)\b"
        for match in re.finditer(r"(['\"`])(?:\\.|(?!\1).)*?\1", code):
            widget.tag_add("str", f"1.0+{match.start()}c", f"1.0+{match.end()}c")
        for match in re.finditer(r"\b\d+(?:\.\d+)?\b", code):
            widget.tag_add("num", f"1.0+{match.start()}c", f"1.0+{match.end()}c")
        for match in re.finditer(keywords, code):
            widget.tag_add("kw", f"1.0+{match.start()}c", f"1.0+{match.end()}c")
        for match in re.finditer(r"(?:#|//).*", code):
            widget.tag_add("comment", f"1.0+{match.start()}c", f"1.0+{match.end()}c")

    def _copy_code(self, code: str, label) -> None:
        self.root.clipboard_clear()
        self.root.clipboard_append(code)
        label.configure(text="Copied", fg=GREEN)
        self.root.after(1200, lambda: label.winfo_exists() and label.configure(text="Copy", fg=BLUE))

    def _set_plain_text(self, widget: tk.Text, text: str, editable=False) -> None:
        widget.insert(tk.END, text)
        count = widget.count("1.0", "end-1c", "displaylines")
        widget.configure(height=max(1, count[0] if count else 1))

    def _update_message_height_for_widget(self, widget: tk.Text) -> None:
        for item in self.message_widgets:
            if item.get("text_widget") is widget:
                self._update_message_height(item)
                break

    def _append_user_message(self, content: str) -> None:
        if not self.chat_items:
            self._clear_chat_widgets()
        item = {"role": "user", "text": content, "streaming": False}
        self.chat_items.append(item)
        self._render_item(item)
        self._scroll_bottom()

    def _begin_assistant_message(self) -> None:
        item = {"role": "assistant", "text": "", "streaming": True}
        self.chat_items.append(item)
        self._active_response = item
        self._response_streaming = True
        self._render_item(item)
        self._start_typing_indicator()
        self._scroll_bottom()

    def _receive_tokens(self, tokens: str) -> None:
        item = self._active_response
        if not item or not self._response_streaming:
            return
        item["text"] += tokens
        typing = item.pop("typing_widget", None)
        if typing and typing.winfo_exists():
            typing.destroy()
        widget = item.get("text_widget")
        if widget and widget.winfo_exists():
            widget.configure(state="normal")
            widget.insert(tk.END, tokens)
            self._set_plain_height(widget)
            widget.configure(state="disabled")
            widget.see(tk.END)
            self._update_message_height(item)
            self._update_message_height(item)
        self._scroll_bottom()

    def _set_plain_height(self, widget: tk.Text) -> None:
        count = widget.count("1.0", "end-1c", "displaylines")
        widget.configure(height=max(1, count[0] if count else 1))

    def _finish_assistant_message(self, content: str, completed: bool) -> None:
        item = self._active_response
        if item is None:
            return
        if content:
            item["text"] = content
        item["streaming"] = False
        self._response_streaming = False
        self._stop_typing_indicator()
        typing = item.pop("typing_widget", None)
        if typing and typing.winfo_exists():
            typing.destroy()
        if item.get("text_widget") and item["text_widget"].winfo_exists():
            self._render_markdown(item["text_widget"], item["text"])
        self._active_response = None
        if not completed and not item["text"]:
            try:
                self.chat_items.remove(item)
                item["row_widget"].destroy()
            except (ValueError, tk.TclError):
                pass
        self._scroll_bottom()

    def _drain_events(self) -> None:
        tokens = []
        queue = self.assistant.events.events
        while not queue.empty():
            event = queue.get_nowait()
            kind = event[0]
            if kind == "generation_token":
                tokens.append(event[1])
                continue
            if tokens:
                self._receive_tokens("".join(tokens))
                tokens.clear()
            if kind == "state":
                self._set_state(event[1], event[2])
            elif kind == "message":
                if event[1].casefold() == "you":
                    self._append_user_message(event[2])
            elif kind == "log":
                self._append_system(event[1])
            elif kind == "generation_start":
                self._begin_assistant_message()
            elif kind == "generation_end":
                self._finish_assistant_message(event[1], event[2])
            elif kind == "conversation_reset":
                self.chat_items = []
                self._show_welcome()
            elif kind == "conversation_saved":
                if self._history_open:
                    self._refresh_history()
        if tokens:
            self._receive_tokens("".join(tokens))
        self.root.after(30, self._drain_events)

    def _append_system(self, message: str) -> None:
        if not self.chat_items:
            self._clear_chat_widgets()
        error = any(word in message.casefold() for word in ("failed", "error", "unavailable", "couldn’t"))
        item = {"role": "system", "text": message, "streaming": False, "error": error}
        self.chat_items.append(item)
        self._render_item(item)
        self._scroll_bottom()

    def _set_state(self, state: AssistantState, message: str = "") -> None:
        self.state = state
        mapping = {
            AssistantState.ONLINE: ("Online", GREEN),
            AssistantState.LISTENING: ("Listening", BLUE),
            AssistantState.TRANSCRIBING: ("Thinking", BLUE),
            AssistantState.THINKING: ("Thinking", BLUE),
            AssistantState.SPEAKING: ("Speaking", GREEN),
            AssistantState.PAUSED: ("Paused", AMBER),
            AssistantState.CANCELLED: ("Online", MUTED),
            AssistantState.ERROR: ("Offline", RED),
            AssistantState.SHUTTING_DOWN: ("Offline", MUTED),
        }
        label, color = mapping[state]
        self.status_text.configure(text=label)
        self.status_dot.configure(fg=color)
        if state in (AssistantState.THINKING, AssistantState.SPEAKING):
            self.stop_button.grid()
        else:
            self.stop_button.grid_remove()
        if state == AssistantState.ERROR and message:
            self._append_system(message)

    def _animate_status(self) -> None:
        self._status_phase = (self._status_phase + 1) % 2
        if not self.preferences.get("reduce_motion") and self.state in (AssistantState.LISTENING, AssistantState.THINKING, AssistantState.SPEAKING):
            colors = {AssistantState.LISTENING: BLUE, AssistantState.THINKING: "#4f86ca", AssistantState.SPEAKING: GREEN}
            self.status_dot.configure(fg=colors[self.state] if self._status_phase else "#48505a")
        if self._typing_active:
            self._typing_phase = (self._typing_phase + 1) % 4
            if self._active_response and not self._active_response["text"]:
                label = self._active_response.get("typing_widget")
                if label and label.winfo_exists():
                    dots = "●  ●  ●" if self.preferences.get("reduce_motion") else "· " * (1 + self._typing_phase % 3)
                    label.configure(text=dots)
        interval = 800 if self.preferences.get("reduce_motion") else 500
        self.root.after(interval, self._animate_status)

    def _start_typing_indicator(self) -> None:
        self._typing_active = True

    def _stop_typing_indicator(self) -> None:
        self._typing_active = False

    def _on_chat_resize(self, event) -> None:
        self.chat_canvas.itemconfigure(self.message_window, width=event.width)
        if self._resize_job:
            self.root.after_cancel(self._resize_job)
        self._resize_job = self.root.after(100, self._resize_messages)

    def _resize_messages(self) -> None:
        self._resize_job = None
        lane_width = min(MAX_LANE, max(320, self.chat_canvas.winfo_width() - 72))
        for item in self.chat_items:
            content = item.get("main_frame")
            if content and content.winfo_exists():
                content.configure(width=lane_width)
            if item.get("role") == "assistant":
                widget = item.get("text_widget")
                if widget and widget.winfo_exists():
                    widget.configure(width=self._body_chars())
                    if not item.get("streaming"):
                        self._render_markdown(widget, item["text"])
                    else:
                        self._set_plain_height(widget)
            else:
                widget = item.get("text_widget")
                if widget and widget.winfo_exists():
                    if item.get("role") == "user":
                        max_line = max((len(line) for line in item["text"].splitlines()), default=22)
                        widget.configure(width=min(self._body_chars(), max(22, max_line)))
                    elif item.get("role") == "system":
                        widget.configure(wraplength=max(260, lane_width))
        self._scroll_bottom()

    def _on_messages_changed(self, _event=None) -> None:
        self.chat_canvas.configure(scrollregion=self.chat_canvas.bbox("all"))

    def _on_mousewheel(self, event) -> None:
        widget_path = str(event.widget)
        chat_path = str(self.chat_canvas)
        in_chat = widget_path == chat_path or widget_path.startswith(chat_path + ".")
        if in_chat and self.chat_canvas.winfo_exists():
            self.chat_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
            return "break"
        return None

    def _scroll_bottom(self) -> None:
        self.root.after_idle(lambda: self.chat_canvas.yview_moveto(1.0) if self.chat_canvas.winfo_exists() else None)

    def close(self) -> None:
        self.assistant.shutdown()
        self.root.destroy()
