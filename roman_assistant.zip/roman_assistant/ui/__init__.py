"""Roman desktop interface."""
