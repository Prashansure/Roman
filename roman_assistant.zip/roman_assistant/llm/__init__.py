"""Local language model integration."""
