"""Connects capture, transcription, local chat, and speech workers."""

import threading
from pathlib import Path

from audio.microphone import Microphone
from audio.whisper import Transcriber
from core.state import AssistantState, EventBus
from llm.ollama_client import OllamaClient
from memory.memory_manager import MemoryManager
from speech.tts import Speech


class Assistant:
    def __init__(self) -> None:
        self.events = EventBus()
        self.microphone = None
        self.transcriber = Transcriber()
        self.llm = OllamaClient()
        self.memory = MemoryManager()
        self.speech = Speech()
        self._lock = threading.Lock()
        self._processing = False
        self._listening = False
        self._closed = False
        self._cancel_requested = threading.Event()
        self._state = AssistantState.ONLINE

    def _state_to(self, state: AssistantState, message: str = "") -> None:
        self._state = state
        self.events.publish("state", state, message)

    def toggle_listening(self) -> None:
        if self._closed:
            return
        if self._listening:
            self.microphone.stop()
            self.events.publish("log", "Microphone stopping…")
            return
        if self._processing:
            self.events.publish("log", "Roman is still working on the current request.")
            return
        try:
            self.microphone = Microphone()
            self._cancel_requested.clear()
            self._listening = True
            self.speech.cancel()
            self._state_to(AssistantState.LISTENING, "Listening · press C to stop")
            self.events.publish("log", "Listening. Speak naturally, then press C to finish.")
            self.microphone.start(self._recording_stopped)
        except Exception as exc:
            self._listening = False
            self._state_to(AssistantState.ERROR, f"Microphone unavailable: {exc}")

    def _recording_stopped(self, filename: Path | None, error: str | None) -> None:
        self._listening = False
        if error:
            self._state_to(AssistantState.ERROR, f"Microphone error: {error}")
            return
        if filename is None:
            self._state_to(AssistantState.ONLINE, "No audio captured")
            return
        self._state_to(AssistantState.TRANSCRIBING, "Transcribing audio…")
        threading.Thread(
            target=self._transcribe_and_answer,
            args=(filename,),
            name="roman-transcription",
            daemon=True,
        ).start()

    def _transcribe_and_answer(self, filename: Path) -> None:
        try:
            query = self.transcriber.transcribe(str(filename))
            if self._cancel_requested.is_set():
                self._state_to(AssistantState.ONLINE, "Ready")
                return
            if self.transcriber.notice:
                self.events.publish("log", self.transcriber.notice)
                self.transcriber.notice = ""
            if not query:
                self.events.publish("log", "No clear speech detected. Try again when ready.")
                self._state_to(AssistantState.ONLINE, "Ready")
                return
            self.events.publish("message", "You", query)
            self._answer(query)
        except Exception as exc:
            self._state_to(AssistantState.ERROR, f"Transcription failed: {exc}")
        finally:
            filename.unlink(missing_ok=True)

    def send_message(self, query: str) -> None:
        query = query.strip()
        if not query:
            return
        if self._processing or self._listening:
            self.events.publish("log", "Finish the current request before sending another message.")
            return
        self.speech.cancel()
        self._cancel_requested.clear()
        self.events.publish("message", "You", query)
        threading.Thread(target=self._answer, args=(query,), name="roman-answer", daemon=True).start()

    def _answer(self, query: str) -> None:
        with self._lock:
            if self._processing:
                self.events.publish("log", "Roman is already handling a request.")
                return
            self._processing = True
        try:
            self._state_to(AssistantState.THINKING, "Thinking…")
            self.events.publish("generation_start")
            turn_session_id = self.memory.session_id
            history = list(self.memory.recent_history)
            long_term_memory = self.memory.memory_for_prompt()
            parts = []
            for token in self.llm.stream(
                query,
                history=history,
                memory=long_term_memory,
            ):
                if self._cancel_requested.is_set():
                    break
                parts.append(token)
                self.events.publish("generation_token", token)
            answer = "".join(parts).strip()
            completed = not self._cancel_requested.is_set()
            self.events.publish("generation_end", answer, completed)
            if not completed:
                self._state_to(AssistantState.ONLINE, "Ready")
                return
            # Persistence failures are contained by MemoryManager and never stop chat.
            if self.memory.add_turn(query, answer, session_id=turn_session_id):
                self.events.publish("conversation_saved")
            try:
                extraction = self.llm.extract_memories(query, answer)
                self.memory.update_memories(extraction)
            except Exception as exc:
                print(f"[MEMORY] Memory extraction failed: {exc}")
            if self._cancel_requested.is_set():
                self._state_to(AssistantState.ONLINE, "Ready")
                return
            self._state_to(AssistantState.SPEAKING, "Roman is speaking")
            self.speech.speak(answer)
            if self._state not in (AssistantState.PAUSED, AssistantState.CANCELLED):
                self._state_to(AssistantState.ONLINE, "Ready")
        except Exception as exc:
            self.events.publish("generation_end", "", False)
            self._state_to(AssistantState.ERROR, f"Couldn’t reach the local model: {exc}")
        finally:
            with self._lock:
                self._processing = False

    def pause(self) -> None:
        self.speech.pause()
        self._state_to(AssistantState.PAUSED, "Speech paused · press A to resume")

    def resume(self) -> None:
        self.speech.resume()
        if self._processing:
            self._state_to(AssistantState.SPEAKING, "Roman is speaking")

    def cancel(self) -> None:
        self._cancel_requested.set()
        self.speech.cancel()
        self._state_to(AssistantState.CANCELLED, "Response cancelled")
        self._state_to(AssistantState.ONLINE, "Ready")

    def new_conversation(self) -> None:
        if self._processing or self._listening or self._state == AssistantState.TRANSCRIBING:
            self.cancel()
        self.memory.start_new_conversation()
        self.events.publish("conversation_reset")

    def load_conversation(self, session_id: str):
        if self._processing or self._listening or self._state == AssistantState.TRANSCRIBING:
            self.cancel()
        return self.memory.load_conversation(session_id)

    def shutdown(self) -> None:
        self._closed = True
        self._state_to(AssistantState.SHUTTING_DOWN, "Roman is closing")
        if self.microphone:
            self.microphone.close()
        self.speech.close()
