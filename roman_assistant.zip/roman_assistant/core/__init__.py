"""Assistant orchestration and state."""
